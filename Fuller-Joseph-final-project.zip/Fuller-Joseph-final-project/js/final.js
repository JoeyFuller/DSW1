// JavaScript Document
alert("Hello, Welcome to our site");